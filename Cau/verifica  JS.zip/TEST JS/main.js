console.log("ENGIM FINAL TEST 2023");

// OBBIETTIVO DEL TEST:
// Creare un layout simile a quelo indicato nell immagine layout.png utilizzando i dati forniti dall api 'https://reqres.in/api/users'

// PARTE A1 (obbligatoria) (50 punti)
// Effetture una richiesta http all api 'https://reqres.in/api/users'
// stampare i dati degli utenti ricevuti dal server in console

// PARTE A2 (obbligatoria) (20 punti)
// Utilizzando i dati ricevuti dal server nel punto precedente:
// Per ogni utente ricevuto dal server, creare una card contenente un elemento per ogni proprietà dell'utente:
// first_name, last_name, email, id, avatar

// PARTE B (Facoltativa) (10 punti)
// In ogni card creare un elemento cliccabile con un mailto che apra il mailer di default con l'email dell'utente preimpostata
// ES: <a href="mailto:useremail@gmail.com">Contact</a>

// PARTE C (Facoltativa) (20 punti)
// Ripodurre il layout presente nell immagine layout.png presente in questa directory
// La scritta contact presente in ogni card deve essere cliccabile e eseguire il mailto con l email dell utente

// Parte D (Facoltativa) (20 punti)
// Creare una paginazione che permetta di visualizzare gli utenti successivi/precedenti utilizzando 2 bottoni

// NOTE:
// IL massimo punteggio raggiungibile è: 100 punti.
// Le parti A1 e A2 sono obbligatorie, le altre sono facoltative e possono essere svolte indipendentemente tra loro.
// Se non riesci a completare una parte facoltativa, puoi comunque provare a completare le altre.
// Puoi ottenere punti anche se non completi al 100% una parte per cui consiglio di provare comunque.



fetch('https://reqres.in/api/users')
.then(function(response){
    console.log("then 1:", response)
    if (response.status === 200){
        console.log("success")
        return response.json()
    }
    else{
        console.log("Error")
    }
})
.then(function(data){
        console.log("then 2:", data)
        let group = document.getElementById('container')
        group.style.display = "flex"
        for( i = 0; i < data.data.length; i++){
            
            let card = document.createElement('div')
            card.classList="card"
            id = document.createElement('h2')
            id.innerText = data.data[i].id
            card.append(id)
            first_name = document.createElement('h1')
            first_name.innerText = data.data[i].first_name
            card.append(first_name)
            last_name = document.createElement('h2')
            last_name.innerText = data.data[i].last_name
            card.append(last_name)
            email = document.createElement('p')
            email.innerText = data.data[i].email
            card.append(email)
            foto = document.createElement('img')
            foto.style= "width:250px"
            foto.src = data.data[i].avatar
            card.append(foto)

            group.append(card)

        }
        
        
    })
.catch(function (error){
    console.log({ error });
})



